/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package nivel.basico;
import java.util.Scanner;
/**
 *
 * @author jjoli
 */
public class caso_contraseña {
        public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);
        String claveGuardada = "300332"; // contraseña fija

        System.out.print("Ingrese la contraseña: ");
        String claveIngresada = entrada.nextLine();

        if (claveIngresada.equals(claveGuardada)) {
            System.out.println("Bienvenido, acceso concedido");
        } else {
            System.out.println("Contraseña incorrecta, acceso denegado");
        }
        entrada.close();
    }
}
    

