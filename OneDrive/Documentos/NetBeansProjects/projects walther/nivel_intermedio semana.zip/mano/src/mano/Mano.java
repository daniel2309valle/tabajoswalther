/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package mano;

/**
 *
 * @author jjoli
 */
import java.util.Scanner;
public class Mano {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
    Scanner entrada = new Scanner(System.in);
    int numero = 0;
     System.out.print("ingrese un numero del 1 al 7: ");
      numero = entrada.nextInt();
    
     
     switch(numero) {
         case 1: System.out.println("lunes");break;
         case 2: System.out.println("martes");break;
         case 3: System.out.println("miercoles");break;
         case 4: System.out.println("jueves");break;
         case 5: System.out.println("viernes");break;
         case 6: System.out.println("sabado");break;
         case 7: System.out.println("domingo");break;
         default: System.out.print("numero invalido");break;
         
     }   
    }
}