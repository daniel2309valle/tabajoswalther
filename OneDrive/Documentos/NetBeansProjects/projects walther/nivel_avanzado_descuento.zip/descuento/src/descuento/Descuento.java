/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package descuento;

/**
 *
 * @author jjoli
 */
 import java.util.Scanner;
public class Descuento {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner entrada = new Scanner(System.in);

        System.out.print("Ingrese el precio total de la compra: ");
        double precio = entrada.nextDouble();

        System.out.print("Ingrese su tipo de membresía (A, B o C): ");
        String tipo = entrada.next().toUpperCase();

        double descuento = 0;

        switch(tipo) {
            case "A": descuento = 0.20; break; // 20%
            case "B": descuento = 0.10; break; // 10%
            case "C": descuento = 0.05; break; // 5%
            default: System.out.println("Membresía inválida"); return;
        }

        double precioFinal = precio - (precio * descuento);

        // descuento extra si supera 100
        if (precioFinal > 100) {
            precioFinal = precioFinal - (precioFinal * 0.05);
        }

        System.out.println("Precio final con descuentos: $" + precioFinal);
        entrada .close();
    }
}

    

