/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package pomedio;

/**
 *
 * @author jjoli
 */
public class Pomedio {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int numero1 = 5;
        int numero2 = 3;
        int numero3 = 50;
        int resultado = 0;
        
        resultado = (numero1 + numero2 + numero3);
        
       System.out.println("el resultado de la suma de los 3 numeros es " + resultado);
    }
    
}
