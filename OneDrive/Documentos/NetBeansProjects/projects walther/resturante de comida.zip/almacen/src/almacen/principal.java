/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package almacen;
import java.util.Scanner;
public class principal {

    public static void main(String[] args) {

        Scanner teclado = new Scanner(System.in);

        double descuento = 0;
        double total = 0;
        double adicion = 0;

        Producto op = new Producto();

        int aparecerM;
        int menu;

        System.out.println("Desea el Menu? (ingrese si o no)");
        String respuesta = teclado.next();

        if (respuesta.equalsIgnoreCase("si")) {

            System.out.println("");
            System.out.println("MENU");
            System.out.println("Precio          Adicion              Descuento");
            System.out.println("1. Bandeja paisa    25.000          Chicharro/Chorizo       Descuento10%");
            System.out.println("2. Mondongo         20.000          Ensalada/patacon        Descuento15%");
            System.out.println("3. Sancocho         25.000          Ensalada/Arroz          Descuento10%");
            System.out.println("4. Menu del dia     20.000          N/A                     N/A");

            System.out.println("");
            System.out.println("Que desea ordenar");
            menu = teclado.nextInt();

            switch (menu) {

                case 1:
                    op.paisa(total, descuento, adicion);
                    break;

                case 2:
                    op.mondongo(total, descuento, adicion);
                    break;

                case 3:
                    op.sancocho(total, descuento, adicion);
                    break;

                case 4:
                    op.menuDia(total, descuento, adicion);
                    break;

                default:
                    System.out.println("Opcion no valida");
                    break;
            }

        } else {
            System.out.println("Gracias por visitar El Buen Sabor");
        }
    }
}