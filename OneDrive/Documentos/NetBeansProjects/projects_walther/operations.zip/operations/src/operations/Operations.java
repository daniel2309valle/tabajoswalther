/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package operations;

/**
 *
 * @author jjoli
 */
public class Operations {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int operation = 2;
        int numero1 = 8;
        int numero2 = 6;
        int resultado = 0;
        
if (operation ==1){ 
    resultado = numero1 + numero2;
    System.out.println("el resultado de la suma es:" + resultado);
}
else if (operation ==2){
    resultado = numero1 - numero2;
    System.out.println("el resultado de la resta es:" + resultado);
}        
else if (operation ==3){
    resultado = numero1 * numero2;
    System.out.println("el resultado de la multiplicacion es:" + resultado);
}
else if (operation ==4){
    resultado = numero1 / numero2;
    System.out.println("el resultado de la division es:" + resultado); 
}
   }
}