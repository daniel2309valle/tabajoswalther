/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pastel;

/**
 *
 * @author jjoli
 */
public class cafeteria {
    
    String marca;
    String color;
    
    public cafeteria(String marca, String color){
        this.marca= marca;
        this.color=color;
    }
    
    
    public void prepararcafe(){
        System.out.println("1. calentando el agua a 90°....");
        System.out.println("2. filtrando el agua a traves deñ cafe molido...");
        System.out.println("3. tucafe esta listo");
       
    }
}

