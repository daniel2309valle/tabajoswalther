/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package pastel;

/**
 *
 * @author jjoli
 */
public class Pastel {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       cafeteria micafetera =new cafeteria("oster","negro");
       
       micafetera.prepararcafe();
    }
    
}
