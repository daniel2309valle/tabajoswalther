/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package estaciones;

/**
 *
 * @author jjoli
 */  
import java.util.Scanner;
public class Estaciones {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);
        System.out.print("Ingrese un año: ");
        int año = entrada.nextInt();

        if (año % 4 == 0) {
            if (año % 100 == 0) {
                if (año % 400 == 0) {
                    System.out.println("El año es bisiesto");
                } else {
                    System.out.println("El año NO es bisiesto");
                }
            } else {
                System.out.println("El año es bisiesto");
            }
        } else {
            System.out.println("El año NO es bisiesto");
        }
        entrada.close();
    }
}


