/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author jjoli
 */
public class Empleados {

    String Nombre;
    String Documento;
    String Cargo;
    String Area;
    double Salario;
    String Fecha;
    
    public Empleados(){
    }

    public Empleados(String Nombre, String Documento, String Cargo, String Area, double Salario, String Fecha) {
        this.Nombre = Nombre;
        this.Documento = Documento;
        this.Cargo = Cargo;
        this.Area = Area;
        this.Salario = Salario;
        this.Fecha = Fecha;
    }   

    public void setNombre(String Nombre) {
        this.Nombre = Nombre;
    }

    public void setDocumento(String Documento) {
        this.Documento = Documento;
    }

    public void setCargo(String Cargo) {
        this.Cargo = Cargo;
    }

    public void setArea(String Area) {
        this.Area = Area;
    }

    public void setSalario(double Salario) {
        this.Salario = Salario;
    }

    public void setFecha(String Fecha) {
        this.Fecha = Fecha;
    }

    public String getNombre() {
        return Nombre;
    }

    public String getDocumento() {
        return Documento;
    }

    public String getCargo() {
        return Cargo;
    }

    public String getArea() {
        return Area;
    }

    public double getSalario() {
        return Salario;
    }

    public String getFecha() {
        return Fecha;
    }
}
    

