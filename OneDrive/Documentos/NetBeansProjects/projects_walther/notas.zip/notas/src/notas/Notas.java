/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package notas;

/**
 *
 * @author jjoli
 */
public class Notas {

    /*
     * @param args the command line arguments
     */
    public static void main(String[] args) {
     int numero1 = 3;
     int numero2 = 3;
     int numero3 = 5;
     int resultado = 0;
     
     
     
     resultado = (numero1 +numero2 +numero3 /3);
     
     if (resultado >=3.3){
         System.out.println("el estudiante aprobo con una nota de " + resultado);
     }
     else{
         System.out.println("el estudiante reprobo con una nota de "
         + resultado);
     }
          
     }
}
   
