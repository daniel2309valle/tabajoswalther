/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package estacionamietos;

import java.util.Scanner;

/**
 *
 * @author jjoli
 */
public class Estacionamietos {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner entrada = new Scanner(System.in);

        System.out.println("Tipo de vehículo: 1 = Moto, 2 = Carro, 3 = Autobús");
        int tipo = entrada.nextInt();

        System.out.print("Ingrese las horas de estacionamiento: ");
        int horas = entrada.nextInt();

        double tarifaHora = 0;

        switch(tipo) {
            case 1: tarifaHora = 2.0; break; // Moto
            case 2: tarifaHora = 5.0; break; // Carro
            case 3: tarifaHora = 10.0; break; // Autobús
            default: System.out.println("Tipo inválido"); return;
        }

        double total = tarifaHora * horas;

        // descuento si supera 8 horas
        if (horas > 8) {
            total = total * 0.90; // 10% de descuento
        }

        System.out.println("Total a pagar: $" + total);
        entrada.close();
    }
}
    

