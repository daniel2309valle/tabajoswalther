/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package estaciones.del.año;

/**
 *
 * @author jjoli
 */
import java.util.Scanner;
public class EstacionesDelAño {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner entrada = new Scanner(System.in);
        System.out.print("Ingrese el nombre de un mes: ");
        String mes = entrada.nextLine().toLowerCase(); // convierte a minúsculas

        switch(mes) {
            case "diciembre": case "enero": case "febrero":
                System.out.println("Invierno");
                break;
            case "marzo": case "abril": case "mayo":
                System.out.println("Primavera");
                break;
            case "junio": case "julio": case "agosto":
                System.out.println("Verano");
                break;
            case "septiembre": case "octubre": case "noviembre":
                System.out.println("Otoño");
                break;
            default:
                System.out.println("Mes inválido");
                break;
        }
        entrada.close();
    }
}


